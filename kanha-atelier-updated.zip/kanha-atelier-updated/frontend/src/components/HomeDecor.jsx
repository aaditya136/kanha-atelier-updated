import { MessageCircle } from "lucide-react";
import { buildWhatsAppLink } from "../lib/whatsapp";

const HOME_DECOR_ITEMS = [
  {
    id: "KA-DCR-001",
    name: "Gothic Arch Corner Wall Shelf",
    subtitle: "Black Cathedral Arch Display Shelf",
    description:
      "A striking matte-black corner wall shelf with hand-carved gothic arch detailing — five pointed arches supported by slender columns. Perfect for displaying candles, books, or curios in entryways, studies, or living rooms.",
    alt: "Black gothic arch corner wall shelf with carved cathedral arches, displayed with a lit pillar candle and antique books",
    image: "/home-decor-gothic-shelf.jpeg",
    tags: ["Wall Decor", "Shelf", "Gothic"],
  },
  {
    id: "KA-DCR-002",
    name: "Tiffany Stained Glass Turtle Lamp",
    subtitle: "Handcrafted Mosaic Night Light",
    description:
      "A charming stained glass turtle accent lamp with a hand-soldered mosaic shell in vivid lime-green and violet. Casts a warm, jewel-toned glow — a collector's piece that doubles as a conversation starter.",
    alt: "Tiffany style stained glass turtle lamp with green and purple mosaic shell, glowing warmly on a table",
    image: "/home-decor-turtle-lamp.jpeg",
    tags: ["Lamp", "Stained Glass", "Accent Light"],
  },
  {
    id: "KA-DCR-003",
    name: "Brass Octopus Figurine",
    subtitle: "Antique Gold Nautical Sculpture",
    description:
      "A finely detailed brass octopus sculpture with textured tentacles and jet-black eyes — inspired by the golden age of seafaring. Ideal as a bookend, desk accent, or shelf centrepiece for the discerning collector.",
    alt: "Antique brass octopus figurine sculpture with detailed tentacles, displayed between leather-bound ocean voyage books on a wooden shelf",
    image: "/home-decor-brass-octopus.jpeg",
    tags: ["Sculpture", "Brass", "Nautical"],
  },
];

export default function HomeDecor() {
  return (
    <section
      id="home-decor"
      data-testid="home-decor-section"
      aria-label="Home Decor Collection"
      className="relative py-28 px-6 lg:px-16 bg-[var(--ka-navy-950)]"
    >
      <div className="max-w-[1440px] mx-auto">
        {/* Section header */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-4">
            <span className="w-10 h-px bg-[var(--ka-gold-400)]" />
            <span className="text-[11px] tracking-[0.4em] uppercase text-[var(--ka-gold-300)]">
              Curated Objects
            </span>
          </div>
          <h2 className="font-display text-4xl sm:text-5xl lg:text-6xl text-[var(--ka-ivory)] leading-[1.05]">
            Home Décor,
            <br />
            <span className="text-[var(--ka-gold-300)] font-serif-italic">
              crafted with intention.
            </span>
          </h2>
          <p className="mt-5 text-[var(--ka-ivory)]/65 max-w-xl text-base leading-relaxed">
            Beyond the loom — a curated selection of decorative objects that
            share our philosophy: slow craft, lasting beauty, and pieces that
            carry a story. Each available for bespoke enquiry via WhatsApp.
          </p>
        </div>

        <div className="gold-rule mb-12" />

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {HOME_DECOR_ITEMS.map((item) => {
            const link = buildWhatsAppLink({
              productName: item.name,
              productId: item.id,
              priceLabel: "Enquire for price",
            });
            return (
              <article
                key={item.id}
                className="ka-card group flex flex-col"
                data-testid={`home-decor-card-${item.id}`}
              >
                <div className="relative aspect-[4/5] overflow-hidden bg-[var(--ka-navy-800)]">
                  <img
                    src={item.image}
                    alt={item.alt}
                    loading="lazy"
                    width={600}
                    height={750}
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-[1400ms] ease-out group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(6,14,34,0.85)] via-transparent to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="tier-chip">Home Décor</span>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <div className="text-[10px] tracking-[0.3em] uppercase text-[var(--ka-ivory)]/55">
                      {item.id}
                    </div>
                    <div className="font-display text-xl sm:text-2xl text-[var(--ka-ivory)] mt-1">
                      {item.name}
                    </div>
                  </div>
                </div>

                <div className="p-6 flex-1 flex flex-col">
                  <p className="text-[11px] tracking-[0.2em] uppercase text-[var(--ka-gold-300)]/80 mb-3">
                    {item.subtitle}
                  </p>

                  <p className="text-sm text-[var(--ka-ivory)]/70 font-serif leading-relaxed flex-1">
                    {item.description}
                  </p>

                  <div className="mt-4 flex flex-wrap gap-2">
                    {item.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[9px] tracking-[0.25em] uppercase border border-[rgba(212,175,55,0.3)] text-[var(--ka-ivory)]/60 px-2 py-1"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="mt-6">
                    <a
                      href={link}
                      target="_blank"
                      rel="noreferrer noopener"
                      className="btn-gold inline-flex items-center gap-2 w-full justify-center"
                      data-testid={`home-decor-whatsapp-${item.id}`}
                    >
                      <MessageCircle size={14} />
                      Enquire via WhatsApp
                    </a>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
